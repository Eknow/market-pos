<?php

class PerfilModuloControlador{


    static public function ctrRegistrarPerfilModulo($idModulos, $idPerfil){

        $registroPerfilModulo = PerfilModuloModelo::mdlRegistrarPerfilModulo($idModulos, $idPerfil);

        return $registroPerfilModulo;
    }

}