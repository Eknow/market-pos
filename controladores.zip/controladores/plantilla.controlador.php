<?php

class PlantillaControlador{

    public function CargarPlantilla(){
        include "vistas/plantilla.php";
    }
}